#include "CondFormats/DataRecord/interface/HcalTimingParamsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
EVENTSETUP_RECORD_REG(HcalTimingParamsRcd);
