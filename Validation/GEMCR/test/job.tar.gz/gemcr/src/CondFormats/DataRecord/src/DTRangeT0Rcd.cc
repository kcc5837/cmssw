#include "CondFormats/DataRecord/interface/DTRangeT0Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DTRangeT0Rcd);
