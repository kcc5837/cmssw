// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelDisabledModulesRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Sat Apr 19 02:11:49 CDT 2008
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelDisabledModulesRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelDisabledModulesRcd);
