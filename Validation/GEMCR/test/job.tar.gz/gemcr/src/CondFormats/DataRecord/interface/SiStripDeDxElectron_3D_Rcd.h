#ifndef CondFormats_SiStripDeDxElectron_3D_Rcd_h
#define CondFormats_SiStripDeDxElectron_3D_Rcd_h

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiStripDeDxElectron_3D_Rcd : public edm::eventsetup::EventSetupRecordImplementation<SiStripDeDxElectron_3D_Rcd> {};

#endif
