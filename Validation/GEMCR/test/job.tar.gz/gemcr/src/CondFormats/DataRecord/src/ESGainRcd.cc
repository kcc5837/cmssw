#include "CondFormats/DataRecord/interface/ESGainRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(ESGainRcd);
