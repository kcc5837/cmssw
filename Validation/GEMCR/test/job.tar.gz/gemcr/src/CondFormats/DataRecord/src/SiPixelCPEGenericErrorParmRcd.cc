// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelCPEGenericErrorParmRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Nov 11 23:07:06 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelCPEGenericErrorParmRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelCPEGenericErrorParmRcd);
