#ifndef DataRecord_SiPixelTemplateDBObject38TRcd_h
#define DataRecord_SiPixelTemplateDBObject38TRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelTemplateDBObject38TRcd
// 
/**\class SiPixelTemplateDBObject38TRcd SiPixelTemplateDBObject38TRcd.h CondFormats/DataRecord/interface/SiPixelTemplateDBObject38TRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Mon Sep 28 15:40:47 CEST 2009
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiPixelTemplateDBObject38TRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixelTemplateDBObject38TRcd> {};

#endif
