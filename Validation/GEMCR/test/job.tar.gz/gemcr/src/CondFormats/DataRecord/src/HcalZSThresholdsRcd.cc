// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HcalZSThresholdsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Sat Nov 24 16:42:00 CET 2007
// $Id$

#include "CondFormats/DataRecord/interface/HcalZSThresholdsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HcalZSThresholdsRcd);
