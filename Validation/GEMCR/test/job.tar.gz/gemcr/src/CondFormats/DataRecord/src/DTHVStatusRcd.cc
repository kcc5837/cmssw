#include "CondFormats/DataRecord/interface/DTHVStatusRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DTHVStatusRcd);
