#include "CondFormats/DataRecord/interface/PFCalibrationRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(PFCalibrationRcd);
