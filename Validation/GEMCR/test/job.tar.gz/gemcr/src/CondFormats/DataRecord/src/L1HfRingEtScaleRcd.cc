// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1HfRingEtScaleRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim Brooke
// Created:     Wed Oct  4 16:49:43 CEST 2006
// $Id: 

#include "CondFormats/DataRecord/interface/L1HfRingEtScaleRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1HfRingEtScaleRcd);
