#ifndef DTT0RANGERCD_H
#define DTT0RANGERCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTT0RangeRcd : public edm::eventsetup::EventSetupRecordImplementation<DTT0RangeRcd> {};
#endif
