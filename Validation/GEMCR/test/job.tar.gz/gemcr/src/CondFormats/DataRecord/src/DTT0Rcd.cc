#include "CondFormats/DataRecord/interface/DTT0Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DTT0Rcd);
