#ifndef CSCDBCHIPSPEEDCORRECTIONRCD_H
#define CSCDBCHIPSPEEDCORRECTIONRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCDBChipSpeedCorrectionRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCDBChipSpeedCorrectionRcd> {};
#endif
