// -*- C++ -*-
//
// Package:     OptAlignObjects
// Class  :     InclinometersRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Jul 20 14:30:27 CEST 2006
// $Id$

#include "CondFormats/DataRecord/interface/InclinometersRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(InclinometersRcd);
