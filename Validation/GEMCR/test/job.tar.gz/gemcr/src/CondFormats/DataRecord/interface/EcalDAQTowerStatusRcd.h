#ifndef ECALDAQTOWERSTATUSRCD_H
#define ECALDAQTOWERSTATUSRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalDAQTowerStatusRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalDAQTowerStatusRcd> {};
#endif
