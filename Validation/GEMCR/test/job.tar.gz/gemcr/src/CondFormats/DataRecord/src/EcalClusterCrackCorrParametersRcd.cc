#include "CondFormats/DataRecord/interface/EcalClusterCrackCorrParametersRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalClusterCrackCorrParametersRcd);
