// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorPedestalWidthsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Feb 11 12:18:02 CET 2008
// $Id: CastorPedestalWidthsRcd.cc,v 1.1 2008/02/15 15:53:56 mccauley Exp $

#include "CondFormats/DataRecord/interface/CastorPedestalWidthsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CastorPedestalWidthsRcd);
