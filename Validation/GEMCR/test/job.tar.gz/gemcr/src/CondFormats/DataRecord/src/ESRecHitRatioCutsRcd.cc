#include "CondFormats/DataRecord/interface/ESRecHitRatioCutsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(ESRecHitRatioCutsRcd);
