// -*- C++ -*-
//
// Package:     CondFormats/DataRecord
// Class  :     HBHENegativeEFilterRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      Igor Volobouev
// Created:     Fri Mar 20 17:06:03 CDT 2015

#include "CondFormats/DataRecord/interface/HBHENegativeEFilterRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HBHENegativeEFilterRcd);
