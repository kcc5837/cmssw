// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCRunIOVRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Mar 26 17:38:10 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/RPCRunIOVRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCRunIOVRcd);
