// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelGainCalibrationOfflineSimRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Mar 13 12:13:12 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelGainCalibrationOfflineSimRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelGainCalibrationOfflineSimRcd);
