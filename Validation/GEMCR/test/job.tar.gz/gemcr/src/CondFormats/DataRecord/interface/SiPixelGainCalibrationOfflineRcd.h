#ifndef DataRecord_SiPixelGainCalibrationOfflineRcd_h
#define DataRecord_SiPixelGainCalibrationOfflineRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelGainCalibrationOfflineRcd
// 
/**\class SiPixelGainCalibrationOfflineRcd SiPixelGainCalibrationOfflineRcd.h CondFormats/DataRecord/interface/SiPixelGainCalibrationOfflineRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Oct  3 19:11:28 CEST 2006
// $Id: SiPixelGainCalibrationOfflineRcd.h,v 1.1 2006/10/20 09:09:15 chiochia Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiPixelGainCalibrationOfflineRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixelGainCalibrationOfflineRcd> {};

#endif
