// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HcalCalibrationQIEDataRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Sat Mar  1 15:49:07 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/HcalCalibrationQIEDataRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HcalCalibrationQIEDataRcd);
