// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorChannelQualityRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Feb 11 12:15:32 CET 2008
// $Id: CastorChannelQualityRcd.cc,v 1.1 2008/02/15 15:53:55 mccauley Exp $

#include "CondFormats/DataRecord/interface/CastorChannelQualityRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CastorChannelQualityRcd);
