#ifndef CastorElectronicsMapRcd_H
#define CastorElectronicsMapRcd_H
#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CastorElectronicsMapRcd : public edm::eventsetup::EventSetupRecordImplementation<CastorElectronicsMapRcd> {};
#endif
