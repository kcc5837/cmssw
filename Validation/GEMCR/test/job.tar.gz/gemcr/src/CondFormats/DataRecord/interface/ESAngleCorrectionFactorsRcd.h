#ifndef CondFormats_DataRecord_ESAngleCorrectionFactorsRcd_H
#define CondFormats_DataRecord_ESAngleCorrectionFactorsRcd_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class ESAngleCorrectionFactorsRcd : public edm::eventsetup::EventSetupRecordImplementation<ESAngleCorrectionFactorsRcd> {};
#endif
