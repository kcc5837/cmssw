#ifndef ECALTPGWEIGHTGROUPRCD_H
#define ECALTPGWEIGHTGROUPRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalTPGWeightGroupRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalTPGWeightGroupRcd> {};
#endif
