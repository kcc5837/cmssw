// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     JetCorrectorParametersRecord
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Wed Mar 10 12:03:17 CET 2010
// $Id$

#include "CondFormats/DataRecord/interface/JetCorrectorParametersRecord.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(JetCorrectorParametersRecord);
