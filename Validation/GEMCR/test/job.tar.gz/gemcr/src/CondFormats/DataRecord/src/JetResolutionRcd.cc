// -*- C++ -*-
// Author: Sébastien Brochet

#include "CondFormats/DataRecord/interface/JetResolutionRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(JetResolutionRcd);
