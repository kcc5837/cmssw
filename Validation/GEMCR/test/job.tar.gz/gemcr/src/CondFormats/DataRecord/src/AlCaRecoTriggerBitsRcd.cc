// -*- C++ -*-
// $Id$

#include "CondFormats/DataRecord/interface/AlCaRecoTriggerBitsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(AlCaRecoTriggerBitsRcd);
