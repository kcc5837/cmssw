#ifndef DataRecord_RunNumberRcd_h
#define DataRecord_RunNumberRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RunNumberRcd
// 
/**\class RunNumberRcd RunNumberRcd.h CondFormats/DataRecord/interface/RunNumberRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Wed May 28 11:20:27 CEST 2008
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RunNumberRcd : public edm::eventsetup::EventSetupRecordImplementation<RunNumberRcd> {};

#endif
