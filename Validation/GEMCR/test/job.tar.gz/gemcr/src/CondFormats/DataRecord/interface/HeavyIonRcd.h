#ifndef DataRecord_HeavyIonRcd_h
#define DataRecord_HeavyIonRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HeavyIonRcd
// 
/**\class 

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Jul 10 05:49:16 EDT 2007
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class HeavyIonRcd : public edm::eventsetup::EventSetupRecordImplementation<HeavyIonRcd> {};

#endif
