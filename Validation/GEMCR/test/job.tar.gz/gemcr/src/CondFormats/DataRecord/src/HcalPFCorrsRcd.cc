// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HcalPFCorrsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Sat Mar  1 15:49:28 CET 2008
// $Id: HcalPFCorrsRcd.cc,v 1.1 2009/05/19 16:05:40 rofierzy Exp $

#include "CondFormats/DataRecord/interface/HcalPFCorrsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HcalPFCorrsRcd);
