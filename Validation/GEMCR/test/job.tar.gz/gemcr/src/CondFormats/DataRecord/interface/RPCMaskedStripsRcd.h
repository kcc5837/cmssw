#ifndef DataRecord_RPCMaskedStripsRcd_h
#define DataRecord_RPCMaskedStripsRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCMaskedStripsRcd
// 
/**\class RPCMaskedStripsRcd RPCMaskedStripsRcd.h CondFormats/DataRecord/interface/RPCMaskedStripsRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Wed Nov 03 15:48:55 CEST 2008
// $Id: RPCMaskedStripsRcd.h,v 1.3 2008/11/03 18:55:37 sanabria Exp $
//




#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RPCMaskedStripsRcd : public edm::eventsetup::EventSetupRecordImplementation<RPCMaskedStripsRcd> {};

#endif
