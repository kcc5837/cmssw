#ifndef CondFormats_DataRecord_ESMissingEnergyCalibration_H
#define CondFormats_DataRecord_ESMissingEnergyCalibration_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class ESMissingEnergyCalibrationRcd : public edm::eventsetup::EventSetupRecordImplementation<ESMissingEnergyCalibrationRcd> {};
#endif
