#ifndef CSCIDENTIFIERRCD_H
#define CSCIDENTIFIERRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCIdentifierRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCIdentifierRcd> {};
#endif // CSCIDENTIFIERRCD_H
