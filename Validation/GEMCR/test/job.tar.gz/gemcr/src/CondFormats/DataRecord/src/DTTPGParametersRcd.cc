#include "CondFormats/DataRecord/interface/DTTPGParametersRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DTTPGParametersRcd);
