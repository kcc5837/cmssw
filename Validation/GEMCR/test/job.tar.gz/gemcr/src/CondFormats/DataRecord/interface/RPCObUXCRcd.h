#ifndef DataRecord_RPCObUXCRcd_h
#define DataRecord_RPCObUXCRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObUXCRcd
// 
/**\class RPCObUXCRcd RPCObUXCRcd.h CondFormats/DataRecord/interface/RPCObUXCRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Mon Nov 16 12:18:42 CET 2009
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RPCObUXCRcd : public edm::eventsetup::EventSetupRecordImplementation<RPCObUXCRcd> {};

#endif
