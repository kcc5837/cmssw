#ifndef DataRecord_BTagTrackProbability3DRcd_h
#define DataRecord_BTagTrackProbability3DRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     BTagTrackProbability3DRcd
// 
/**\class BTagTrackProbability3DRcd BTagTrackProbability3DRcd.h CondFormats/DataRecord/interface/BTagTrackProbability3DRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Thu Jan 11 09:36:33 CET 2007
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class BTagTrackProbability3DRcd : public edm::eventsetup::EventSetupRecordImplementation<BTagTrackProbability3DRcd> {};

#endif
