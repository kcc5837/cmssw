#ifndef CSCCROSSTALKRCD_H
#define CSCCROSSTALKRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCcrosstalkRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCcrosstalkRcd> {};
#endif
