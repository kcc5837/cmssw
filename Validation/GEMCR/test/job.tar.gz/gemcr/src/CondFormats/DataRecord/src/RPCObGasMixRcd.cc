// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObGasMixRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Oct 10 09:56:32 CEST 2008
// $Id: RPCObGasMixRcd.cc,v 1.2 2008/12/12 17:32:40 dpagano Exp $

#include "CondFormats/DataRecord/interface/RPCObGasMixRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObGasMixRcd);
