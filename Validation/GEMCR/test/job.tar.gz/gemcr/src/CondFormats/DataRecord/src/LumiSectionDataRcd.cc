#include "CondFormats/DataRecord/interface/LumiSectionDataRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(LumiSectionDataRcd);


