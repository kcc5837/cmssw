// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     BTagTrackProbability2DRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Jan 11 09:36:33 CET 2007
// $Id$

#include "CondFormats/DataRecord/interface/BTagTrackProbability2DRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(BTagTrackProbability2DRcd);
