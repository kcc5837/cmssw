#ifndef CondFormats_DYTThrObjectRcd_h
#define CondFormats_DYTThrObjectRcd_h

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class DYTThrObjectRcd : public edm::eventsetup::EventSetupRecordImplementation<DYTThrObjectRcd> {};

#endif
