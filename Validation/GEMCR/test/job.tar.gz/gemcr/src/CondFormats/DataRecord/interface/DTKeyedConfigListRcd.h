#ifndef DTKeyedConfigListRCD_H
#define DTKeyedConfigListRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTKeyedConfigListRcd : public edm::eventsetup::EventSetupRecordImplementation<DTKeyedConfigListRcd> {};
#endif
