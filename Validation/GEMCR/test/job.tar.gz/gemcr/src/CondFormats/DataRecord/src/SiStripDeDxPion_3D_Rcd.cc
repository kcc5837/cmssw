#include "CondFormats/DataRecord/interface/SiStripDeDxPion_3D_Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiStripDeDxPion_3D_Rcd);
