// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     EcalLaserAPDPNRatiosRefRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Jun  1 12:31:01 CEST 2007
// $Id$

#include "CondFormats/DataRecord/interface/EcalLaserAPDPNRatiosRefRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalLaserAPDPNRatiosRefRcd);
