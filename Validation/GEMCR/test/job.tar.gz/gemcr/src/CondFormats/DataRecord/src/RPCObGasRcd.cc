// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObGasRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Oct 10 09:56:32 CEST 2008
// $Id$

#include "CondFormats/DataRecord/interface/RPCObGasRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObGasRcd);
