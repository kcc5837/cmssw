// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorPedestalsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Feb 11 12:17:40 CET 2008
// $Id: CastorPedestalsRcd.cc,v 1.1 2008/02/15 15:53:56 mccauley Exp $

#include "CondFormats/DataRecord/interface/CastorPedestalsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CastorPedestalsRcd);
