#include "CondFormats/DataRecord/interface/SiStripDeDxPion_2D_Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiStripDeDxPion_2D_Rcd);
