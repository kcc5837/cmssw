#ifndef CSCDBCROSSTALKRCD_H
#define CSCDBCROSSTALKRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCDBCrosstalkRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCDBCrosstalkRcd> {};
#endif
