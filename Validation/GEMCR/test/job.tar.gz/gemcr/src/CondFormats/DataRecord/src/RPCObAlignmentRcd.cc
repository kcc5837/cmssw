// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObAlignmentRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Mar 24 11:26:21 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/RPCObAlignmentRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObAlignmentRcd);
