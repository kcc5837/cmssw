#ifndef DataRecord_SiPixelPerformanceSummaryRcd_h
#define DataRecord_SiPixelPerformanceSummaryRcd_h


#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"


class SiPixelPerformanceSummaryRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixelPerformanceSummaryRcd> {};


#endif
