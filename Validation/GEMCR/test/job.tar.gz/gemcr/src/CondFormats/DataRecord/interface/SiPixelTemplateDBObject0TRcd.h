#ifndef DataRecord_SiPixelTemplateDBObject0TRcd_h
#define DataRecord_SiPixelTemplateDBObject0TRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelTemplateDBObject0TRcd
// 
/**\class SiPixelTemplateDBObject0TRcd SiPixelTemplateDBObject0TRcd.h CondFormats/DataRecord/interface/SiPixelTemplateDBObject0TRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Mon Sep 28 15:40:32 CEST 2009
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiPixelTemplateDBObject0TRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixelTemplateDBObject0TRcd> {};

#endif
