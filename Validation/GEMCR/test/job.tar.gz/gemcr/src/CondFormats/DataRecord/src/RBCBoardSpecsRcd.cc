// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RBCBoardSpecsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Dec 11 17:47:19 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/RBCBoardSpecsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RBCBoardSpecsRcd);
