// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObGasHumRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Oct 10 09:56:32 CEST 2008
// $Id: RPCObGasHumRcd.cc,v 1.1 2009/12/13 10:05:39 dpagano Exp $

#include "CondFormats/DataRecord/interface/RPCObGasHumRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObGasHumRcd);
