#include "CondFormats/DataRecord/interface/L1RCTNoisyChannelMaskRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1RCTNoisyChannelMaskRcd);
