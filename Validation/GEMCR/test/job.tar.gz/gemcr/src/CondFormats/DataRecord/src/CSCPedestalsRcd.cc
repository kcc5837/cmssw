#include "CondFormats/DataRecord/interface/CSCPedestalsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CSCPedestalsRcd);
