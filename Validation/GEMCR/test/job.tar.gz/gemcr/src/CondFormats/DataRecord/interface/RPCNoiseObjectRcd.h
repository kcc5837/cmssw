#ifndef DataRecord_RPCNoiseObjectRcd_h
#define DataRecord_RPCNoiseObjectRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCNoiseObjectRcd
// 
/**\class RPCNoiseObjectRcd RPCNoiseObjectRcd.h CondFormats/DataRecord/interface/RPCNoiseObjectRcd.h

 Description: [one line class summary]

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Wed Nov  2 17:37:55 CET 2011
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RPCNoiseObjectRcd : public edm::eventsetup::EventSetupRecordImplementation<RPCNoiseObjectRcd> {};

#endif
