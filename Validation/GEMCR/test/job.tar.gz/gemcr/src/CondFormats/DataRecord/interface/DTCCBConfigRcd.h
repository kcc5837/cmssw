#ifndef DTCCBConfigRCD_H
#define DTCCBConfigRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTCCBConfigRcd : public edm::eventsetup::EventSetupRecordImplementation<DTCCBConfigRcd> {};
#endif
