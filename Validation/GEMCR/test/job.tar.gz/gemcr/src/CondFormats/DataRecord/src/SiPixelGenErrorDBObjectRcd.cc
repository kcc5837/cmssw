// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelGenErrorDBObjectRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Nov 11 23:08:00 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelGenErrorDBObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelGenErrorDBObjectRcd);
