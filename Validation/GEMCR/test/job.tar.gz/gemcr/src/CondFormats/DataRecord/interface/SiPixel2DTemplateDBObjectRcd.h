#ifndef DataRecord_SiPixel2DTemplateDBObjectRcd_h
#define DataRecord_SiPixel2DTemplateDBObjectRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixel2DTemplateDBObjectRcd
// 
/**\class SiPixel2DTemplateDBObjectRcd SiPixelTemplateDBObjectRcd.h CondFormats/DataRecord/interface/SiPixelTemplateDBObjectRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Nov 11 23:08:00 CET 2008
// $Id: SiPixel2DTemplateDBObjectRcd.h,v 1.1 2008/11/12 18:13:03 dfehling Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiPixel2DTemplateDBObjectRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixel2DTemplateDBObjectRcd> {};

#endif
