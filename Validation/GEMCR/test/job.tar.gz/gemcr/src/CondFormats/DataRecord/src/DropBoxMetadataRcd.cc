// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     DropBoxMetadataRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Wed Feb 23 11:26:01 CET 2011
// $Id$

#include "CondFormats/DataRecord//interface/DropBoxMetadataRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DropBoxMetadataRcd);
