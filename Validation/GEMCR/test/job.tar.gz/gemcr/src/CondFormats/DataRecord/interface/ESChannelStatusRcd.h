#ifndef CondFormats_DataRecord_ESChannelStatus_H
#define CondFormats_DataRecord_ESChannelStatus_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class ESChannelStatusRcd : public edm::eventsetup::EventSetupRecordImplementation<ESChannelStatusRcd> {};
#endif
