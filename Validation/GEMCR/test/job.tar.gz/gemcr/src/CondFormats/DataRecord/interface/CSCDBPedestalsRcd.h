#ifndef CSCDBPEDESTALSRCD_H
#define CSCDBPEDESTALSRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCDBPedestalsRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCDBPedestalsRcd> {};
#endif
