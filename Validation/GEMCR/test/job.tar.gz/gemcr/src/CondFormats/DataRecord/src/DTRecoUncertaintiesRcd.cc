// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     DTRecoUncertaintiesRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Wed Feb 23 11:26:01 CET 2011
// $Id: DTRecoUncertaintiesRcd.cc,v 1.1 2011/02/25 14:20:28 cerminar Exp $

#include "CondFormats/DataRecord//interface/DTRecoUncertaintiesRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DTRecoUncertaintiesRcd);
