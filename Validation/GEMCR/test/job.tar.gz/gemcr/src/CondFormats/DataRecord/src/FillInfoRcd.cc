// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     FillInfoRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Tue Apr 10 19:38:43 CEST 2012
// $Id$

#include "CondFormats/DataRecord/interface/FillInfoRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(FillInfoRcd);
