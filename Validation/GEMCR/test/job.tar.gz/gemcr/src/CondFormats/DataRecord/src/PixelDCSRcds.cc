#include "CondFormats/DataRecord/interface/PixelDCSRcds.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(PixelCaenChannelIsOnRcd);
EVENTSETUP_RECORD_REG(PixelCaenChannelIMonRcd);
EVENTSETUP_RECORD_REG(PixelCaenChannelRcd);
