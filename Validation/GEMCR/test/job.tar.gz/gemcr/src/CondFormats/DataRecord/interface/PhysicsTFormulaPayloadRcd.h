#ifndef PhysicsTFormulaPayloadRcd_PhysicsTFormulaPayloadRcd_h
#define PhysicsTFormulaPayloadRcd_PhysicsTFormulaPayloadRcd_h
// -*- C++ -*-
//
// Package:     CondFormats/DataRecord
// Class  :     PhysicsTFormulaPayloadRcd
// 
/**\class PhysicsTFormulaPayloadRcd PhysicsTFormulaPayloadRcd.h CondFormats/DataRecord/interface/PhysicsTFormulaPayloadRcd.h

 Description: [one line class summary]

 Usage:
    <usage>

*/
//
// Author:      Christian Veelken
// Created:     Fri, 24 Jan 2014 18:42:23 GMT
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class PhysicsTFormulaPayloadRcd : public edm::eventsetup::EventSetupRecordImplementation<PhysicsTFormulaPayloadRcd> {};

#endif
