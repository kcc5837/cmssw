#ifndef JetResolutionRcd_h
#define JetResolutionRcd_h
// -*- C++ -*-
// Author: Sébastien Brochet
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class JetResolutionRcd : public edm::eventsetup::EventSetupRecordImplementation<JetResolutionRcd> {};

#endif
