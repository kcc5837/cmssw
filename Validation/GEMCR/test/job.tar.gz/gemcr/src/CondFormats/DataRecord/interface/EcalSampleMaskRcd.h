#ifndef CondFormats_DataRecord_EcalSampleMask_H
#define CondFormats_DataRecord_EcalSampleMask_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalSampleMaskRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalSampleMaskRcd> {};
#endif
