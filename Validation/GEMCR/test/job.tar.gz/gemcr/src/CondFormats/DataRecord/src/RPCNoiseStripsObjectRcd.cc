// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCNoiseStripsObjectRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Wed Nov  2 17:37:55 CET 2011
// $Id: RPCNoiseStripsObjectRcd.cc,v 1.2 2011/11/07 08:09:34 mmaggi Exp $

#include "CondFormats/DataRecord/interface/RPCNoiseStripsObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCNoiseStripsObjectRcd);
