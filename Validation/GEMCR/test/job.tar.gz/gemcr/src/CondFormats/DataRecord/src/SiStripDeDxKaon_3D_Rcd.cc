#include "CondFormats/DataRecord/interface/SiStripDeDxKaon_3D_Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiStripDeDxKaon_3D_Rcd);
