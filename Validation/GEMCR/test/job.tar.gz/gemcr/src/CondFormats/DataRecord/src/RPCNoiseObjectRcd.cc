// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCNoiseObjectRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Wed Nov  2 17:37:55 CET 2011
// $Id$

#include "CondFormats/DataRecord/interface/RPCNoiseObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCNoiseObjectRcd);
