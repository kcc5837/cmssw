// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HeavyIonRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Jul 10 05:49:16 EDT 2007
// $Id$

#include "CondFormats/DataRecord/interface/HeavyIonRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HeavyIonRcd);
