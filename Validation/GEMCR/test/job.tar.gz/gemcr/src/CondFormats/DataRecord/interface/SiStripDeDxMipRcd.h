#ifndef CondFormats_SiStripDeDxMipRcd_h
#define CondFormats_SiStripDeDxMipRcd_h

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiStripDeDxMipRcd : public edm::eventsetup::EventSetupRecordImplementation<SiStripDeDxMipRcd> {};

#endif
