// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     EcalShowerContainmentCorrectionRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Mar  2 16:50:49 CET 2007
// $Id: EcalShowerContainmentCorrectionsLogE2E1Rcd.cc,v 1.1.2.1 2007/05/15 20:55:17 argiro Exp $

#include "CondFormats/DataRecord/interface/EcalShowerContainmentCorrectionsLogE2E1Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalShowerContainmentCorrectionsLogE2E1Rcd);
