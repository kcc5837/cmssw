#ifndef ECALTPGSLIDINGWRCD_H
#define ECALTPGSLIDINGWRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalTPGSlidingWindowRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalTPGSlidingWindowRcd> {};
#endif
