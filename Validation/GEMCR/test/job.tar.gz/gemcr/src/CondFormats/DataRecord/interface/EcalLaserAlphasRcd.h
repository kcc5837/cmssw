#ifndef DataRecord_EcalLaserAlphasRcd_h
#define DataRecord_EcalLaserAlphasRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     EcalLaserAlphasRcd
// 
/**\class EcalLaserAlphasRcd EcalLaserAlphasRcd.h CondFormats/DataRecord/interface/EcalLaserAlphasRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Fri Jun  1 12:28:55 CEST 2007
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class EcalLaserAlphasRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalLaserAlphasRcd> {};

#endif
