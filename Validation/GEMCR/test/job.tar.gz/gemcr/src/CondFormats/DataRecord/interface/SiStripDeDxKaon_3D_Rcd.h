#ifndef CondFormats_SiStripDeDxKaon_3D_Rcd_h
#define CondFormats_SiStripDeDxKaon_3D_Rcd_h

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiStripDeDxKaon_3D_Rcd : public edm::eventsetup::EventSetupRecordImplementation<SiStripDeDxKaon_3D_Rcd> {};

#endif
