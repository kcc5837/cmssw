///                                                                                                   
/// \class L1TCaloConfigRcd
///
/// Description: see header file
///
/// Implementation:
///


#include "CondFormats/DataRecord/interface/L1TCaloConfigRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1TCaloConfigRcd);
