// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HLTPrescaleTableRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Thu Feb 25 15:41:50 CET 2010
// $Id$

#include "CondFormats/DataRecord/interface/HLTPrescaleTableRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HLTPrescaleTableRcd);
