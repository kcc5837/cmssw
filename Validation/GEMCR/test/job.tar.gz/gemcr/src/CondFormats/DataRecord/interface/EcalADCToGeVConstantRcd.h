#ifndef CondFormats_DataRecord_EcalADCToGeVConstant_H
#define CondFormats_DataRecord_EcalADCToGeVConstant_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalADCToGeVConstantRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalADCToGeVConstantRcd> {};
#endif
