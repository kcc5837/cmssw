// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelTemplateDBObjectRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Nov 11 23:08:00 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelTemplateDBObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelTemplateDBObjectRcd);
