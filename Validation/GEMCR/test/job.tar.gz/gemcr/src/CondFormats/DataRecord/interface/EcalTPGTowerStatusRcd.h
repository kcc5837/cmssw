#ifndef ECALTPGTOWERSTATUSRCD_H
#define ECALTPGTOWERSTATUSRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalTPGTowerStatusRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalTPGTowerStatusRcd> {};
#endif
