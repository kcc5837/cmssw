#ifndef CondFormats_DropBoxMetadataRcd_h
#define CondFormats_DropBoxMetadataRcd_h
// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     DropBoxMetadataRcd
// 
/**\class DropBoxMetadataRcd DropBoxMetadataRcd.h src/CondFormats/interface/DropBoxMetadataRcd.h

 Description: [one line class summary]

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Wed Feb 23 11:26:01 CET 2011
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class DropBoxMetadataRcd : public edm::eventsetup::EventSetupRecordImplementation<DropBoxMetadataRcd> {};

#endif
