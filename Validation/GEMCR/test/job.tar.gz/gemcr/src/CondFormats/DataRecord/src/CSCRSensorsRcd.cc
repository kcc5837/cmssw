#include "CondFormats/DataRecord/interface/CSCRSensorsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
// #include "FWCore/Modules/src/SealModule.cc"
// #include "FWCore/Framework/interface/SourceFactory.h"

EVENTSETUP_RECORD_REG(CSCRSensorsRcd);
// DEFINE_FWK_EVENTSETUP_SOURCE(CSCZSensorsRcd);
