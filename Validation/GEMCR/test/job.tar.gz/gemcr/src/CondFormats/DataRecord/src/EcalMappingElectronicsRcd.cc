#include "CondFormats/DataRecord/interface/EcalMappingElectronicsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalMappingElectronicsRcd);
