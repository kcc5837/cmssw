// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1GctJetFinderParamsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Jul 10 10:14:03 CEST 2007
// $Id$

#include "CondFormats/DataRecord/interface/L1GctJetFinderParamsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1GctJetFinderParamsRcd);
