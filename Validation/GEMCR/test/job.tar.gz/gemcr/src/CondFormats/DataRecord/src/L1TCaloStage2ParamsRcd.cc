// Description: see header file

#include "CondFormats/DataRecord/interface/L1TCaloStage2ParamsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1TCaloStage2ParamsRcd);
