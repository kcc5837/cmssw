// this file is generated automatically by /afs/fnal.gov/files/home/room1/ratnikov/bin/makeNewClass.sh
// name: ratnikov, date: Tue Oct 18 18:59:54 CDT 2005
#include "CondFormats/DataRecord/interface/HcalElectronicsMapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
EVENTSETUP_RECORD_REG(HcalElectronicsMapRcd);
