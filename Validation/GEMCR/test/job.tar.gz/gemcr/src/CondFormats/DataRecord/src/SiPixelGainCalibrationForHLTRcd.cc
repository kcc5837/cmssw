// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelGainCalibrationForHLTRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Oct  3 19:11:28 CEST 2006
// $Id: SiPixelGainCalibrationForHLTRcd.cc,v 1.1 2006/10/20 09:09:15 chiochia Exp $

#include "CondFormats/DataRecord/interface/SiPixelGainCalibrationForHLTRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelGainCalibrationForHLTRcd);
