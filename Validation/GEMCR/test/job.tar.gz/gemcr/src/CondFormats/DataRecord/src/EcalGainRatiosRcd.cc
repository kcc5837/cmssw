#include "CondFormats/DataRecord/interface/EcalGainRatiosRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalGainRatiosRcd);
