#ifndef CSCBADSTRIPSRCD_H
#define CSCBADSTRIPSRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCBadStripsRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCBadStripsRcd> {};
#endif
