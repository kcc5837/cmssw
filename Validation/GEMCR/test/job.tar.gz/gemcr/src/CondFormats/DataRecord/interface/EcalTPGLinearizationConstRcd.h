#ifndef ECALTPGLINCONSTRCD_H
#define ECALTPGLINCONSTRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalTPGLinearizationConstRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalTPGLinearizationConstRcd> {};
#endif
