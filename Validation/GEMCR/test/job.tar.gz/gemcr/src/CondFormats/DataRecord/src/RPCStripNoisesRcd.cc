// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCStripNoisesRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Apr 21 15:48:55 CEST 2008
// $Id: RPCStripNoisesRcd.cc,v 1.1 2008/05/12 08:34:24 trentad Exp $

#include "CondFormats/DataRecord/interface/RPCStripNoisesRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCStripNoisesRcd);
