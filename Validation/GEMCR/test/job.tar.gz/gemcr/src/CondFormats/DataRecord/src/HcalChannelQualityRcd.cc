// this file is generated automatically by /afs/fnal.gov/files/home/room1/ratnikov/bin/makeNewClass.sh
// name: ratnikov, date: Thu Oct 20 01:13:51 CDT 2005
#include "CondFormats/DataRecord/interface/HcalChannelQualityRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
EVENTSETUP_RECORD_REG(HcalChannelQualityRcd);
