// -*- C++ -*-

// Author:      Dmitrijus Bugelskis
// Created:     Thu, 14 Nov 2013 17:12:16 GMT

#include "CondFormats/DataRecord/interface/EcalTimeBiasCorrectionsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalTimeBiasCorrectionsRcd);
