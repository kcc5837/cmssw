#include "CondFormats/GEMObjects/interface/GEMDeadStrips.h"
#include "FWCore/Utilities/interface/Exception.h"
