#include "CondFormats/GEMObjects/interface/GEMEMap.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(GEMEMap);
