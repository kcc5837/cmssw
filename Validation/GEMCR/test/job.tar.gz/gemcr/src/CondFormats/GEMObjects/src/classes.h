#include "CondFormats/GEMObjects/interface/GEMEMap.h"


namespace{
  struct dictionary {

  };
}
