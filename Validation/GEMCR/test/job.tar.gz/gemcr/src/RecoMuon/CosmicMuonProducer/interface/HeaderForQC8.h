#ifndef CosmicMuonProducer_HeaderForQC8_H
#define CosmicMuonProducer_HeaderForQC8_H

#define QC8FLAG_SEEDINFO_REFVERTROLL18  0x00000001

#endif //CosmicMuonProducer_HeaderForQC8_H



